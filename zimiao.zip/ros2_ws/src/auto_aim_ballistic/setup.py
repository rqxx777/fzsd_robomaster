from setuptools import setup

package_name = 'auto_aim_ballistic'

setup(
    name=package_name,
    version='0.0.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='lll',
    maintainer_email='lll@todo.todo',
    description='TODO',
    license='TODO',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'auto_aim_node = auto_aim_ballistic.auto_aim_node:main',
            'ekf_tracker = auto_aim_ballistic.ekf_tracker:main',
        ],
    },
)
