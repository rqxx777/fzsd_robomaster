#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PoseStamped, PointStamped
from nav_msgs.msg import Odometry
from visualization_msgs.msg import Marker
import numpy as np

class EKFTracker(Node):


    def __init__(self):
        super().__init__('ekf_tracker')

        # ---------- 可调参数 ----------
        self.declare_parameter('q_pos', 0.01)      
        self.declare_parameter('q_vel', 0.1)      
        self.declare_parameter('r_pos', 0.05)      
        self.declare_parameter('dt', 0.05)         
        self.declare_parameter('predict_horizon', 0.3)  
        self.declare_parameter('frame_id', 'odom') 

        # 从参数服务器获取初始值
        self.q_pos = self.get_parameter('q_pos').value
        self.q_vel = self.get_parameter('q_vel').value
        self.r_pos = self.get_parameter('r_pos').value
        self.dt = self.get_parameter('dt').value
        self.predict_horizon = self.get_parameter('predict_horizon').value
        self.frame_id = self.get_parameter('frame_id').value

        # 状态向量 [x, y, z, vx, vy, vz]
        self.x = np.zeros((6, 1))
        self.P = np.eye(6) * 10.0          # 初始协方差较大，表示不确定
        self.F = np.eye(6)                 # 状态转移矩阵
        self.F[0:3, 3:6] = self.dt * np.eye(3)
        self.H = np.zeros((3, 6))
        self.H[0:3, 0:3] = np.eye(3)      # 观测矩阵只取位置
        self.I = np.eye(6)

        self.last_time = self.get_clock().now()
        self.initialized = False

        # 构建过程噪声 Q 和观测噪声 R（初始基于当前参数）
        self.Q = np.eye(6)
        self.R = np.eye(3)
        self._update_noise_matrices()


        self.create_subscription(PoseStamped, '/yolo/target_pose', self.pose_callback, 10)

        # 发布滤波后的 Odometry（包含位置和速度）
        self.odom_pub = self.create_publisher(Odometry, '/filtered_odom', 10)

        # 发布预测点（用于可视化）
        self.pred_pub = self.create_publisher(PointStamped, '/predicted_target', 10)

    
        self.raw_marker_pub = self.create_publisher(Marker, '/raw_target_marker', 10)
        self.filtered_marker_pub = self.create_publisher(Marker, '/filtered_target_marker', 10)

        # 注册参数动态调整回调
        self.add_on_set_parameters_callback(self.parameter_callback)

        self.get_logger().info('EKF Tracker node started.')

    def parameter_callback(self, params):
  
        for param in params:
            if param.name == 'q_pos':
                self.q_pos = param.value
            elif param.name == 'q_vel':
                self.q_vel = param.value
            elif param.name == 'r_pos':
                self.r_pos = param.value
            elif param.name == 'dt':
                self.dt = param.value
            elif param.name == 'predict_horizon':
                self.predict_horizon = param.value
            elif param.name == 'frame_id':
                self.frame_id = param.value
        self._update_noise_matrices()
        self.get_logger().info(
            f'EKF params updated: q_pos={self.q_pos}, q_vel={self.q_vel}, r_pos={self.r_pos}')
        return True

    def _update_noise_matrices(self):

        # 过程噪声模型：离散白噪声加速度 (DWA)
        dt = self.dt
        qp2 = self.q_pos ** 2
        qv2 = self.q_vel ** 2
        self.Q = np.zeros((6, 6))
        # 位置块
        self.Q[0:3, 0:3] = (qp2 + qv2 * dt**3 / 3) * np.eye(3)
        # 交叉块
        self.Q[0:3, 3:6] = (qv2 * dt**2 / 2) * np.eye(3)
        self.Q[3:6, 0:3] = (qv2 * dt**2 / 2) * np.eye(3)
        # 速度块
        self.Q[3:6, 3:6] = (qv2 * dt) * np.eye(3)

        # 观测噪声
        self.R = np.eye(3) * (self.r_pos ** 2)

    def predict(self, dt):

        self.F[0:3, 3:6] = dt * np.eye(3)
        self.x = self.F @ self.x
        self.P = self.F @ self.P @ self.F.T + self.Q

    def update(self, z):

        y = z.reshape((3, 1)) - self.H @ self.x   # 残差
        S = self.H @ self.P @ self.H.T + self.R
        K = self.P @ self.H.T @ np.linalg.inv(S)
        self.x = self.x + K @ y
        self.P = (self.I - K @ self.H) @ self.P

    def pose_callback(self, msg: PoseStamped):

        now = self.get_clock().now()
        dt = (now - self.last_time).nanoseconds / 1e9
        if dt <= 0.0 or dt > 2.0:   # 如果长时间未收到数据，保持 dt 为默认值
            dt = self.dt
        self.last_time = now

        # 确保 Q, R 与当前 dt 匹配（因为 dt 参数可能被动态修改）
        self._update_noise_matrices()

        # 如果不是第一次接收数据，执行预测
        if self.initialized:
            self.predict(dt)
        else:
            # 首次观测：用当前观测初始化状态，速度设为 0
            self.x[0:3] = np.array([[msg.pose.position.x],
                                    [msg.pose.position.y],
                                    [msg.pose.position.z]])
            self.x[3:6] = 0.0
            self.initialized = True

        # 更新
        z = np.array([msg.pose.position.x,
                      msg.pose.position.y,
                      msg.pose.position.z])
        self.update(z)

        
        odom = Odometry()
        odom.header.stamp = now.to_msg()
        odom.header.frame_id = self.frame_id
        odom.child_frame_id = 'target'
        odom.pose.pose.position.x = float(self.x[0])
        odom.pose.pose.position.y = float(self.x[1])
        odom.pose.pose.position.z = float(self.x[2])
       
        odom.pose.pose.orientation.w = 1.0
        # 速度填入 twist
        odom.twist.twist.linear.x = float(self.x[3])
        odom.twist.twist.linear.y = float(self.x[4])
        odom.twist.twist.linear.z = float(self.x[5])
        self.odom_pub.publish(odom)

        # ---------- 发布未来预测点 ----------
        t_pred = self.predict_horizon
        F_pred = np.eye(6)
        F_pred[0:3, 3:6] = t_pred * np.eye(3)
        x_pred = F_pred @ self.x
        pred_msg = PointStamped()
        pred_msg.header.stamp = now.to_msg()
        pred_msg.header.frame_id = self.frame_id
        pred_msg.point.x = float(x_pred[0])
        pred_msg.point.y = float(x_pred[1])
        pred_msg.point.z = float(x_pred[2])
        self.pred_pub.publish(pred_msg)

        
        # 原始观测（红色小球）
        raw_marker = Marker()
        raw_marker.header.stamp = now.to_msg()
        raw_marker.header.frame_id = self.frame_id
        raw_marker.ns = 'raw'
        raw_marker.id = 0
        raw_marker.type = Marker.SPHERE
        raw_marker.action = Marker.ADD
        raw_marker.pose.position = msg.pose.position
        raw_marker.scale.x = 0.1
        raw_marker.scale.y = 0.1
        raw_marker.scale.z = 0.1
        raw_marker.color.r = 1.0
        raw_marker.color.g = 0.0
        raw_marker.color.b = 0.0
        raw_marker.color.a = 1.0
        self.raw_marker_pub.publish(raw_marker)

        # 滤波后位置（绿色小球）
        filt_marker = Marker()
        filt_marker.header.stamp = now.to_msg()
        filt_marker.header.frame_id = self.frame_id
        filt_marker.ns = 'filtered'
        filt_marker.id = 0
        filt_marker.type = Marker.SPHERE
        filt_marker.action = Marker.ADD
        filt_marker.pose.position.x = float(self.x[0])
        filt_marker.pose.position.y = float(self.x[1])
        filt_marker.pose.position.z = float(self.x[2])
        filt_marker.scale.x = 0.12
        filt_marker.scale.y = 0.12
        filt_marker.scale.z = 0.12
        filt_marker.color.r = 0.0
        filt_marker.color.g = 1.0
        filt_marker.color.b = 0.0
        filt_marker.color.a = 1.0
        self.filtered_marker_pub.publish(filt_marker)

def main(args=None):
    rclpy.init(args=args)
    node = EKFTracker()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
