import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PointStamped, PoseStamped
from sensor_msgs.msg import JointState
from .ballistic_solver import BallisticSolver
from nav_msgs.msg import Odometry

class AutoAimNode(Node):
    def __init__(self):
        super().__init__('auto_aim_node')
        self.solver = BallisticSolver(bullet_speed=15.0, gravity=9.81)
        self.shooter_pos = [0.0, 0.0, 0.5]   # 根据实际云台位置修改

        # 订阅目标位姿（这里借 /odom_pose 模拟一个移动目标）
        self.target_sub = self.create_subscription(
            PoseStamped, '/odom_pose', self.target_callback, 10)

        # 发布瞄准点
        self.aim_pub = self.create_publisher(PointStamped, '/aim_point', 10)
        # 发布云台角度
        self.gimbal_pub = self.create_publisher(JointState, '/gimbal_command', 10)

        self.get_logger().info('Auto aim node started')

    def target_callback(self, msg):
        # 提取目标位置
        target_pos = [
            msg.pose.position.x,
            msg.pose.position.y,
            msg.pose.position.z
        ]
        # 速度假设为0（如果要更真实，可以从 /odom_pose 的 twist 或单独话题获取）
        target_vel = [0.0, 0.0, 0.0]

        aim_point, flight_time = self.solver.solve_aim_point(
            self.shooter_pos, target_pos, target_vel
        )

        # 发布 aim_point
        aim_msg = PointStamped()
        aim_msg.header.stamp = self.get_clock().now().to_msg()
        aim_msg.header.frame_id = 'odom'     # 与模拟器坐标系一致
        aim_msg.point.x = aim_point[0]
        aim_msg.point.y = aim_point[1]
        aim_msg.point.z = aim_point[2]
        self.aim_pub.publish(aim_msg)

        # 计算并发布云台角度
        yaw, pitch = self.solver.get_gimbal_angle(self.shooter_pos, aim_point)
        gimbal_msg = JointState()
        gimbal_msg.header.stamp = self.get_clock().now().to_msg()
        gimbal_msg.name = ['yaw_joint', 'pitch_joint']
        gimbal_msg.position = [yaw, pitch]
        self.gimbal_pub.publish(gimbal_msg)

        self.get_logger().info(f'Aim point: ({aim_point[0]:.2f}, {aim_point[1]:.2f}, {aim_point[2]:.2f}), '
                               f'flight time: {flight_time:.3f}s')


def target_callback(self, msg: Odometry):
    target_pos = [msg.pose.pose.position.x,
                  msg.pose.pose.position.y,
                  msg.pose.pose.position.z]
    target_vel = [msg.twist.twist.linear.x,
                  msg.twist.twist.linear.y,
                  msg.twist.twist.linear.z]
    aim_point, t = self.solver.solve_aim_point(self.shooter_pos, target_pos, target_vel)
    # ... 发布 aim_point 等

def main(args=None):
    rclpy.init(args=args)
    node = AutoAimNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
