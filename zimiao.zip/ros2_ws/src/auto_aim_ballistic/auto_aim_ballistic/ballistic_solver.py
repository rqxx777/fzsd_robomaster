import math
import numpy as np

class BallisticSolver:
    def __init__(self, bullet_speed=15.0, gravity=9.81):
        self.bullet_speed = bullet_speed
        self.gravity = gravity

    def solve_aim_point(self, shooter_pos, target_pos, target_vel):
        dp = np.array(target_pos) - np.array(shooter_pos)
        dv = np.array(target_vel)

        a = np.dot(dv, dv) - self.bullet_speed**2
        b = 2 * np.dot(dp, dv)
        c = np.dot(dp, dp)

        discriminant = b**2 - 4*a*c
        if discriminant < 0:
            return target_pos, 0.0

        t1 = (-b + math.sqrt(discriminant)) / (2*a)
        t2 = (-b - math.sqrt(discriminant)) / (2*a)
        t = t1 if t1 > 0 else t2
        if t <= 0:
            return target_pos, 0.0

        gravity_vec = np.array([0.0, 0.0, -self.gravity])
        aim_point = np.array(target_pos) + dv * t + 0.5 * gravity_vec * t**2
        return aim_point.tolist(), t

    def get_gimbal_angle(self, shooter_pos, aim_point):
        dx = aim_point[0] - shooter_pos[0]
        dy = aim_point[1] - shooter_pos[1]
        dz = aim_point[2] - shooter_pos[2]

        yaw = math.atan2(dy, dx)
        horizontal_dist = math.sqrt(dx**2 + dy**2)
        pitch = math.atan2(dz, horizontal_dist)
        return yaw, pitch
